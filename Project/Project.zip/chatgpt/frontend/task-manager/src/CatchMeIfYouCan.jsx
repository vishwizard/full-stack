import { useState, useEffect, useRef } from "react";

export default function CatchMeIfYouCan() {
  const initialPosition = { top: 100, left: 100 };
  const [position, setPosition] = useState(initialPosition);
  const [windowSize, setWindowSize] = useState({ width: window.innerWidth, height: window.innerHeight });
  const [currentRoast, setCurrentRoast] = useState("");
  const todoRef = useRef(null);
  const [todoRect, setTodoRect] = useState(null);

  // Array of roasts
  const roasts = [
    "Catch me if you can! 😎",
    "Too slow! 😂",
    "Is that all you got? 🤔",
    "Awww, want me to wait?",
    "Full marks dene pdenge agar nahi pakad paye 😉",
    "Noob 😏",
  ];

  useEffect(() => {
    const handleResize = () => {
      setWindowSize({ width: window.innerWidth, height: window.innerHeight });
      if (todoRef.current) {
        setTodoRect(todoRef.current.getBoundingClientRect());
      }
    };
    window.addEventListener("resize", handleResize);
    // Initial measure
    if (todoRef.current) {
      setTodoRect(todoRef.current.getBoundingClientRect());
    }
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  const moveRandomly = () => {
    const iconSize = 50;
    const margin = 20;
    let newTop = margin + Math.random() * (windowSize.height - iconSize - 2 * margin);
    let newLeft;

    if (todoRect) {
      // Allow positioning only outside todoRect horizontally.
      // Two zones: left side or right side of todoRect
      const leftZoneWidth = todoRect.left - margin - iconSize;
      const rightZoneWidth = windowSize.width - (todoRect.right + margin) - iconSize;

      const leftZoneAvailable = leftZoneWidth > 0;
      const rightZoneAvailable = rightZoneWidth > 0;

      if (leftZoneAvailable && rightZoneAvailable) {
        // Randomly choose left or right zone
        if (Math.random() < 0.5) {
          newLeft = margin + Math.random() * leftZoneWidth;
        } else {
          newLeft = todoRect.right + margin + Math.random() * rightZoneWidth;
        }
      } else if (leftZoneAvailable) {
        newLeft = margin + Math.random() * leftZoneWidth;
      } else if (rightZoneAvailable) {
        newLeft = todoRect.right + margin + Math.random() * rightZoneWidth;
      } else {
        // If no left or right zone available (very narrow window), revert to initial left
        newLeft = margin;
      }
    } else {
      // Without todoRect fallback full range
      newLeft = margin + Math.random() * (windowSize.width - iconSize - 2 * margin);
    }

    setPosition({ top: newTop, left: newLeft });

    // Pick a random roast
    const randomIndex = Math.floor(Math.random() * roasts.length);
    setCurrentRoast(roasts[randomIndex]);
  };

  const resetPosition = () => {
    setPosition(initialPosition);
    setCurrentRoast("");
  };

  return (
    <>
      {/* Pass todoRef as prop or get it differently */}
      <div ref={todoRef} style={{ display: "none" }}></div> {/* Hidden placeholder if needed */}
      <svg
        onMouseEnter={moveRandomly}
        xmlns="http://www.w3.org/2000/svg"
        fill="currentColor"
        viewBox="0 0 24 24"
        className="w-12 h-12 text-red-500 cursor-pointer absolute"
        style={{ top: position.top, left: position.left, transition: "top 0.3s, left 0.3s" }}
      >
        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18 c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm-1-13h2v6h-2zm0 8h2v2h-2z"/>
      </svg>
      {currentRoast && (
        <div className="absolute bg-yellow-200 dark:bg-purple-800 text-black dark:text-white px-3 py-1 rounded shadow" style={{ top: position.top - 40, left: position.left }}>
          {currentRoast}
        </div>
      )}

      <button
        onClick={resetPosition}
        className="fixed bottom-5 right-5 px-4 py-2 rounded-lg bg-blue-500 text-white hover:bg-blue-600 transition"
      >
        Reset
      </button>
    </>
  );
}
