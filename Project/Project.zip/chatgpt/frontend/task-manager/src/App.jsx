import { useEffect, useState } from "react";
import axios from "axios";
import ThemeToggle from "./ThemeToggle";
import CatchMeIfYouCan from "./catchmeifyoucan";
import { useRef } from "react";


const API = "http://localhost:8080/api/tasks";

export default function App() {
  const [tasks, setTasks] = useState([]);
  const [title, setTitle] = useState("");
  const todoContainerRef = useRef(null);

  const [confirmLevel, setConfirmLevel] = useState(0);
  const [pendingDeleteId, setPendingDeleteId] = useState(null);
  const [hiddenIds, setHiddenIds] = useState([]);
  const [showAfterMessage, setShowAfterMessage] = useState(false);

  const loadTasks = async () => {
    const res = await axios.get(API);
    setTasks(res.data);
  };

  const addTask = async () => {
    if (!title) return;
    await axios.post(API, { title, completed: false });
    setTitle("");
    loadTasks();
  };

  const toggleTask = async (task) => {
    await axios.put(`${API}/${task.id}`, { ...task, completed: !task.completed });
    loadTasks();
  };

  const handleDeleteClick = (id) => {
    setPendingDeleteId(id);
    setConfirmLevel(1);
  };

  const proceedDelete = async () => {
    if (!pendingDeleteId) return;
    if (confirmLevel < 3) {
      setConfirmLevel((prev) => prev + 1);
      return;
    }
    setConfirmLevel(0);
    setHiddenIds((prev) => [...prev, pendingDeleteId]);
    setTimeout(() => {
      setHiddenIds((prev) => prev.filter((x) => x !== pendingDeleteId));
      setPendingDeleteId(null);
      setShowAfterMessage(true);
      setTimeout(() => setShowAfterMessage(false), 4000);
    }, 3000);
  };

  const superDeleteTask = async (id) => {
    try {
      await axios.delete(`${API}/${id}`);
      setTasks((prev) => prev.filter((task) => task.id !== id));
    } catch (err) {
      console.error("Failed to delete task:", err);
    }
  };

  useEffect(() => {
    loadTasks();
  }, []);

  return (
    <div className="min-h-screen transition-colors duration-300 bg-[#fff7e6] dark:bg-[#0d0b16] text-[#332c22] dark:text-[#e5e1ff] p-10">
          <div ref={todoContainerRef} className="max-w-xl mx-auto">

        <div className="flex justify-between items-center mb-6">
          <h1 className="text-4xl font-bold tracking-tight text-[#4a3b2f] dark:text-[#c7b8ff]">Task Manager</h1>
          <ThemeToggle />
        </div>

        <div className="flex gap-2 mb-6">
          <input
            className="flex-1 p-3 rounded-lg border bg-[#fff2cc] dark:bg-[#1d1733] border-[#f3d8b6] dark:border-[#2d2350] placeholder-[#b8a798] dark:placeholder-[#7a6b9e] focus:ring-2 focus:ring-[#ffd6a5] dark:focus:ring-[#7f5cff] transition-all"
            placeholder="New task..."
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
          <button
            onClick={addTask}
            className="px-4 py-2 rounded-lg font-medium bg-[#ffd6a5] text-[#4a3a2c] dark:bg-[#7f5cff] dark:text-white hover:opacity-90 active:scale-95 transition-all"
          >
            Add
          </button>
        </div>

        {confirmLevel > 0 && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
            <div className="bg-white dark:bg-[#1d1733] p-6 rounded-xl shadow-lg border dark:border-[#3b2d66] max-w-sm text-center">
              {confirmLevel === 1 && <img src="1.webp" alt="Step 1" width="300" height="200" />}
              {confirmLevel === 2 && <img src="2.jpg" alt="Step 2" width="300" height="200" />}
              {confirmLevel === 3 && <img src="duck.jpg" alt="Step 3" width="300" height="200" />}
              <h2 className="text-xl font-bold mb-4">
                {confirmLevel === 1 && "Are you sure?"}
                {confirmLevel === 2 && "Fine but are you really really super sure?"}
                {confirmLevel === 3 && "Last chance, Supreme Leader. Delete?"}
              </h2>
              <div className="flex justify-center gap-4">
                <button
                  onClick={() => { setConfirmLevel(0); setPendingDeleteId(null); }}
                  className="px-4 py-2 rounded bg-gray-300 dark:bg-gray-600"
                >
                  No
                </button>
                <button
                  onClick={proceedDelete}
                  className="px-4 py-2 rounded bg-red-500 text-white hover:bg-red-600 transition"
                >
                  Yes
                </button>
              </div>
            </div>
          </div>
        )}

        <ul className="space-y-3">
          {tasks.map((task) => (
            <li
              key={task.id}
              className={`flex items-center justify-between p-4 rounded-lg bg-[#ffe5ec] dark:bg-[#1d1733] border border-[#f4c6cc] dark:border-[#2e2458] shadow-sm hover:shadow-md transition-all ${hiddenIds.includes(task.id) ? "opacity-0 pointer-events-none" : ""}`}
            >
              <div className="flex items-center gap-3">
                <input
                  type="checkbox"
                  checked={task.completed}
                  onChange={() => toggleTask(task)}
                  className="w-5 h-5 rounded border-[#d6b5b8] dark:border-[#5a4b93] accent-[#f7a8b8] dark:accent-[#4d7cff]"
                />
                <span className={task.completed ? "line-through text-[#a08c86] dark:text-[#7b6fa8]" : "text-lg"}>{task.title}</span>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => handleDeleteClick(task.id)}
                  className="text-[#d9534f] hover:text-[#c9413d] dark:text-[#ff7aa8] dark:hover:text-[#ff8bb5] transition"
                >
                  Delete
                </button>
                <button
                  onClick={() => superDeleteTask(task.id)}
                  className="text-[#b00] hover:text-[#800] dark:text-[#ff4d6d] dark:hover:text-[#ff1a4d] transition border border-2 rounded-l p-2"
                >
                  Super Delete
                </button>
              </div>
            </li>
          ))}
          {hiddenIds.length > 0 && (
          <>
            <img src="aadi.jpg" className="w-48" />
            <p>Aadi...... Aadi.....</p>
          </>
        )}

        {showAfterMessage && (
          <>
            <img src="hila.jpg" className="w-48" />
            <p>Kyu Hila Dala na?</p>
          </>
        )}
        </ul>
      <CatchMeIfYouCan todoRef={todoContainerRef} />
         

      </div>
    </div>
  );
}
